{
    'name':'Demo-1',
    'version':'1.0',
    'depends':['base'],
    'summary':'This the demo version 1',
    "data": ["views/demo_view.xml"],
    'sequence': 10,
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}