from odoo import api, fields, models, _

class PropertyModel(models.Model):
    _inherit = "estate.model"

    ptype = fields.Selection(add_selection=[('Villa','Villa')])
    padd = fields.Text("Property Address")
    pdate = fields.Date("Property Last Bought On")