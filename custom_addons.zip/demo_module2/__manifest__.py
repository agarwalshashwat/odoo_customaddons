{
    "name": "Demo Module2",
    "version": "1.0",
    'summary': 'Test....',
    "author": "TEST",
    'sequence': 10,
    'description': """ Demo Module """,
    'category': 'Demo',
    'website': 'www.google.com',
    "depends": ["demo_module", 'mail'],
    "data": ["views/demo2_view.xml"], 
    'application': True,
}
