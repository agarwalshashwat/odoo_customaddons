#manifest
{
    'name':'Real Estate',
    'version':'1.0',
    'depends':['base'],
    'summary':'List your property on sale',
    "data": ["views/estate_view.xml"],
    'sequence': 10,
    'installable': True,
    'application': True,
}