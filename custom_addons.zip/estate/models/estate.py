from typing import DefaultDict
from odoo import api, fields, models, _
from datetime import date


class EstateModel(models.Model):
    _name = "estate.model"
    _description = "Enlist your on sale property here for better prices"
    _rec_name = "title"

    title = fields.Text(string="Title", required=True)
    ptype = fields.Selection([('Condo','Condo'),('Apartment','Apartment')], string="Property Type",required=True)
    pcode = fields.Char(string="Postal Code",required=True)
    room = fields.Integer(string='Bedrooms')
    lasqm = fields.Integer(string='Living Area(sqm)')
    exp = fields.Float(string='Expected Price')
    sp = fields.Float(string='Selling Price')
    state = fields.Selection([('nfs','Not For Sale'),('offer_received','Offer Received'),('offer_accepted','Offer Accepted'),('sold','Sold')], string='State', default='nfs')
    availfr = fields.Date(string="Available From")
    soldon = fields.Date(string="Sold On", default=date.today())
    best = fields.Float(string='Best Offer')

    desc = fields.Text(string="Description")
    desc_count = fields.Integer(compute='descr_count', string="Description Count",store=True)
    fasc = fields.Boolean(string="Fascades")
    garg = fields.Boolean(string="Garage")
    gard = fields.Boolean(string="Garden")
    tasqm = fields.Float(string="Total Area(sqm)")

    @api.onchange("garg","gard","fasc")
    def gard_garg(self):
        # prev = self.desc
        # prev_ind = prev.index("The property")-1
        # prev = prev[:prev_ind] + " "
        if self.garg & self.gard & self.fasc:
            self.desc = "The property has Garage, Garden and Fascades."
        elif self.garg & self.gard:
            self.desc = "The property has Garage and Garden only."
        elif self.garg & self.fasc:
            self.desc = "The property has Garage and Fascades only."
        elif self.gard & self.fasc:
            self.desc = "The property has Garden and Fascades only."
        elif self.gard:
            self.desc = "The property has Garden only."
        elif self.garg:
            self.desc = "The property has Garage only."
        elif self.fasc:
            self.desc = "The property has Fascade only."
        else:
            self.desc = "The property doesn't has Garage, Garden and Fascades facility."


    @api.depends("desc")
    def descr_count(self):
        for rec in self:
            if rec.desc:
                rec.desc_count = len(rec.desc)
            else:
                rec.desc_count = 0


    def action_nfs(self):
        self.state = "nfs"

    def action_offer_received(self):
        self.state = "offer_received"

    def action_offer_accepted(self):
        self.state = "offer_accepted"

    def action_sold(self):
        self.state = "sold"
    
    def add_profile(self):
        obj = self.env['estate.model.sub'].create({
            "name": self.title,
            "cost": self.sp,
            "type": self.ptype,
            "intro": self.desc,
            "sub_id": self.id
        })

    def update_profile(self):
        obj = self.env["estate.model.sub"].search([('sub_id','=',self.id)])
        if obj:
            obj.write({
                "name": self.title,
                "cost": self.sp,
                "type": self.ptype,
                "intro": self.desc,
            })
    def delete_profile(self):
        obj = self.env['estate.model.sub'].search([('sub_id','=',self.id)])
        if obj:
            obj.unlink()


class EstateModelSub(models.Model):
    _name = "estate.model.sub"
    _description = "Estate Model Submenu"

    name = fields.Char("Property Name")
    cost = fields.Float("Cost of Property")
    type = fields.Char("Property Type")
    intro = fields.Text("Property Intro")
    sub_id = fields.Integer("Property Id")

# class EstateModelDesc(models.Model):
#     __name = "estate.model.desc"
    
#     und = fields.Char("Undertaking Name")
