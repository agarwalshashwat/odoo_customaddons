{
    "name": "Demo Module",
    "version": "1.0",
    'summary': 'Test....',
    "author": "TEST",
    'sequence': 10,
    'description': """ Demo Module """,
    'category': 'Demo',
    'website': 'www.google.com',
    "depends": ["base"],
    "data": ["views/demo_view.xml"], 
    'application': True,
}
