{
    'name':'Property',
    'version':'1.0',
    'depends':['estate'],
    'summary':'List of properties on the estate model',
    'data':['views/property_view.xml'],
    'sequence':11,
    'category':'EstateDemo',
    'application':True,    
}